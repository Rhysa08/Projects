#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TASKS 100
#define MAX_LENGTH 256
#define FILENAME "tasks.txt"

// Global variables for storing tasks
char tasks[MAX_TASKS][MAX_LENGTH];
int task_count = 0;

void clear_screen() {
    // Clear screen based on the operating system
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

int main() {
    int choice;

    // Load tasks from the file if it exists
    FILE *file = fopen(FILENAME, "r");
    if (file != NULL) {
        while (fgets(tasks[task_count], MAX_LENGTH, file) != NULL && task_count < MAX_TASKS) {
            tasks[task_count][strcspn(tasks[task_count], "\n")] = 0; // Remove newline character
            task_count++;
        }
        fclose(file);
    }

    clear_screen(); // Clear screen on start

    // Welcome message
    printf("\033[1;36m===========================================\033[0m\n");
    printf("\033[1;36m        WELCOME TO THE TO-DO LIST        \033[0m\n");
    printf("\033[1;36m===========================================\033[0m\n");
    printf("       Manage Your Tasks Effectively!       \n");

    while (1) {
        printf("\n\033[1;33m----------------------------------------\033[0m\n");
        printf("\033[1;33m               MAIN MENU                \033[0m\n");
        printf("\033[1;33m----------------------------------------\033[0m\n");
        printf("\033[1;32m1. Add a Task\033[0m\n");
        printf("\033[1;32m2. View Tasks\033[0m\n");
        printf("\033[1;32m3. Delete a Task\033[0m\n");
        printf("\033[1;32m4. Exit\033[0m\n");

        printf("\n\033[1;33mEnter your choice (1-4): \033[0m");
        scanf("%d", &choice);
        getchar(); // Clear the buffer

        clear_screen(); // Clear the screen after a choice

        if (choice == 1) {
            if (task_count < MAX_TASKS) {
                printf("\033[1;32mEnter the task description: \033[0m");
                fgets(tasks[task_count], MAX_LENGTH, stdin);
                tasks[task_count][strcspn(tasks[task_count], "\n")] = 0; // Remove newline
                task_count++;
                printf("\033[1;34mTask added successfully!\033[0m\n");
            } else {
                printf("\033[1;31mTask list is full! Cannot add more tasks.\033[0m\n");
            }
        } else if (choice == 2) {
            if (task_count == 0) {
                printf("\033[1;31mNo tasks to show.\033[0m\n");
            } else {
                printf("\033[1;36mYour Tasks:\033[0m\n");
                for (int i = 0; i < task_count; i++) {
                    printf("\033[1;32m%d.\033[0m %s\n", i + 1, tasks[i]);
                }
            }
        } else if (choice == 3) {
            int task_number;
            printf("\033[1;33mEnter the task number to delete: \033[0m");
            scanf("%d", &task_number);
            getchar(); // Clear the buffer

            if (task_number < 1 || task_number > task_count) {
                printf("\033[1;31mInvalid task number!\033[0m\n");
            } else {
                // Shift tasks to remove the selected one
                for (int i = task_number - 1; i < task_count - 1; i++) {
                    strcpy(tasks[i], tasks[i + 1]);
                }
                task_count--;
                printf("\033[1;34mTask deleted successfully!\033[0m\n");
            }
        } else if (choice == 4) {
            printf("\033[1;34mGoodbye! See you later!\033[0m\n");
            break;
        } else {
            printf("\033[1;31mInvalid choice! Please enter a number between 1 and 4.\033[0m\n");
        }

        // Save tasks to file after each operation
        FILE *file = fopen(FILENAME, "w");
        if (file != NULL) {
            for (int i = 0; i < task_count; i++) {
                fprintf(file, "%s\n", tasks[i]);
            }
            fclose(file);
        }

        printf("\n\033[1;33mPress Enter to return to the main menu...\033[0m");
        getchar(); // Wait for the user to press Enter
        clear_screen(); // Clear screen before the next menu
    }

    return 0;
}






