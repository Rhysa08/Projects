#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TASKS 100
#define MAX_LENGTH 256
#define FILENAME "tasks.txt"

// Global variables for storing tasks
char tasks[MAX_TASKS][MAX_LENGTH];
int task_count = 0;

int main() {
    int choice;
    
    // Load tasks from the file
    FILE *file = fopen(FILENAME, "r");
    if (file != NULL) {
        while (fgets(tasks[task_count], MAX_LENGTH, file) != NULL && task_count < MAX_TASKS) {
            tasks[task_count][strcspn(tasks[task_count], "\n")] = 0; // remove newline character
            task_count++;
        }
        fclose(file);
    }

    printf("Welcome to the To-Do List Program\n");

    while (1) {
        printf("\nMenu:\n");
        printf("1. Add a Task\n");
        printf("2. View Tasks\n");
        printf("3. Delete a Task\n");
        printf("4. Exit\n");

        printf("Enter your choice (1-4): ");
        scanf("%d", &choice);
        getchar(); // clear input buffer

        if (choice == 1) {
            if (task_count < MAX_TASKS) {
                printf("Enter the task description: ");
                fgets(tasks[task_count], MAX_LENGTH, stdin);
                tasks[task_count][strcspn(tasks[task_count], "\n")] = 0; // remove newline
                task_count++;
                printf("Task added successfully!\n");
            } else {
                printf("Task list is full!\n");
            }
        } else if (choice == 2) {
            if (task_count == 0) {
                printf("No tasks to show.\n");
            } else {
                printf("Your Tasks:\n");
                for (int i = 0; i < task_count; i++) {
                    printf("%d. %s\n", i + 1, tasks[i]);
                }
            }
        } else if (choice == 3) {
            int task_number;
            printf("Enter the task number to delete: ");
            scanf("%d", &task_number);
            getchar(); // clear input buffer

            if (task_number < 1 || task_number > task_count) {
                printf("Invalid task number!\n");
            } else {
                for (int i = task_number - 1; i < task_count - 1; i++) {
                    strcpy(tasks[i], tasks[i + 1]);
                }
                task_count--;
                printf("Task deleted successfully!\n");
            }
        } else if (choice == 4) {
            printf("Goodbye!\n");
            break;
        } else {
            printf("Invalid choice! Please enter a number between 1 and 4.\n");
        }

        // Save tasks to file
        FILE *file = fopen(FILENAME, "w");
        if (file != NULL) {
            for (int i = 0; i < task_count; i++) {
                fprintf(file, "%s\n", tasks[i]);
            }
            fclose(file);
        }
    }

    return 0;
}





